<?php
$connect = mysqli_connect("localhost", "root", "", "jeepdb");

if ($connect == TRUE) { //echo "asdsadasdasdasdghasdghjasfgjhsdfgjsdhfgsdjhfgsdjfhgsdfhjdsgfjdhsgfjhsdfgdjsfhgdfjshgfjsconnect man";

} else {
    echo "Failed to Connect";

    include("jdatabase.php");
}
?>
<!DOCTYPE html>
<html lang="en">

  <head>
<style>
  input[type=button], input[type=submit], input[type=reset] {
background-color: #04AA6D;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
}

input {
  border: none;
  font-family: 'Open Sans', Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5em;
  padding: 0;
  -webkit-appearance: none;
}

p {
  line-height: 1.5em;
}

after { clear: both; }

#login {
  margin: 50px auto;
  width: 350px;
}

#login form {
  margin: auto;
  padding: 22px 22px 22px 22px;
  width: 100%;
  border-radius: 10px;
  background: #282e33;
  border-top: 3px solid #434a52;
  border-bottom: 3px solid #434a52;
}

#login form span {
  background-color: #363b41;
  border-radius: 3px 0px 0px 3px;
  border-right: 3px solid #434a52;
  color: #606468;
  display: block;
  float: left;
  line-height: 50px;
  text-align: center;
  width: 27px;
  height: 50px;
}

#login form input[type="text"] {
  background-color: #3b4148;
  border-radius: 0px 3px 3px 0px;
  color: #a9a9a9;
  margin-bottom: 1em;
  padding: 0 16px;
  width: 235px;
  height: 50px;
}

#login form input[type="password"] {
  background-color: #3b4148;
  border-radius: 0px 3px 3px 0px;
  color: #a9a9a9;
  margin-bottom: 1em;
  padding: 0 16px;
  width: 235px;
  height: 50px;
}

#login form input[type="submit"] {
 background: linear-gradient(to right, #34aaaa, #035097);
  width: 100%;
  height: 30px;
  border-radius: 3px;
  padding: 5px 15px;
  text-decoration: none;
  margin: 4px 2px;
  color: white;
  cursor: pointer;
  transition: background 0.3s ease-in-out;
}
#login form input[type="submit"]:hover {
  background: #34aaaa;;

}
.copyright {
  margin-top: 30px;
  text-align: center;
    p,a{color: #3dc1f5;
  font-size: 12px;
  text-decoration: none;
  transition: color 0.3s ease-out;
  a:hover{color: #32a89e;
  }
    }
  
}

hr.new1 {
  border-top: 2px solid white;
}

<style>
* {
  box-sizing: border-box;
}

.row {
  display: flex;
}

/* Create two equal columns that sits next to each other */
.column {
  flex: 50%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}
</style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,700">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>iJeep Register Form</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <!-- Additional CSS Files -->
   <link rel="stylesheet" href="jcss/newnamo.css">
  </head>

<body>
  
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
       <br>
       <br>
       <br>

          <!-- ***** Banner Start ***** -->
          <div class="mainbanner">
            <div class="row">
              <div class="col-lg-7">
                <div class="header-text">
                  <h4><em style="color: #34aaaa;">WELCOME</em> to </h4>
                                       <a href="newhome.php" class="logo">
                        <img src="images/logonamo.png" alt="">
                    </a>
                  <h6>No More: Asa naman ang Jeep?</h6>

                  <!-- ***** <h4><em>Browse</em> Our Popular Games Here</h4> ***** -->
                </div>
            </div>
        

        <div id="login" style="">
 <div class="column">
          <form id="login"  method="post">
        <span><i class="fas fa-user"></i></span>
          <input type="text" id="user" placeholder="Enter your First Name" name="fname" required>
          <br>
          <span><i class="fas fa-users"></i></span>
          <input type="text" id="user" placeholder="Enter your Last Name" name="lname" required>
          <br>
        <span><i class="fas fa-envelope"></i></span>
          <input type="text" id="user" placeholder="Email" name="email" required>
          <br>
        <span class="fas fa-lock"></span>
          <input type="password" id="pass" placeholder="Password" name="password" required>
       <input type="submit" name="register_btn" value="JOIN THE GANG !"> 

       <hr class="new1">  <div class="main-button">
                  <button onClick="location.href='newindex.php'" style="width: 100%; color: whitesmoke; background-color:#04AA6D;">Log in to Existing Account</button>
       <?php
            if(isset($_POST['register_btn'])) {
        
                $lname = mysqli_real_escape_string($connect, trim($_POST['lname']));
                $fname = mysqli_real_escape_string($connect, trim($_POST['fname']));
                $email = mysqli_real_escape_string($connect, trim($_POST['email']));
                $password = mysqli_real_escape_string($connect, trim($_POST['password']));

                $sql1 = "SELECT * FROM commuters WHERE email = '$email'";
                $query1 = mysqli_query($connect, $sql1);

                if(mysqli_num_rows($query1) > 0) {
                    echo " <br> <br>
         <strong><center><mark>  
            Email Already Used !</mark></center></strong><br>";

        
                } else {

                $sql = "INSERT INTO commuters (f_name, l_name, email, password, location)
                VALUES ('$fname', '$lname', '$email', '$password', 'Cache');";
                $query = mysqli_query($connect, $sql);
                    $result = mysqli_fetch_array($query1);
                    $_SESSION['email'] = $result['email'];
        
                    echo "<script> alert('Account Successfuly Registered'); window.location='newindex.php'; </script>";
                }
                
            }
        ?>
    </form> </font> </table> </div>
            </form>

                </form>

                  <div class="main-button">
                    <!-- <a href="browse.html">Browse Now</a> -->
                   <!-- <a input type="submit" name="submit" href="" > Log in </a> -->

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ***** Banner End ***** -->
        </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
            <br> <br> <br>
          <p>Copyright © 2022 <a href="#">Team Muggles </a> Group. All rights reserved. 
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>


  </body>

</html>
